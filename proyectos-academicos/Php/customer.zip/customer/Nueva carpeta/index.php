<?php
require_once("./db/db.php");
require_once("./controller/customer_controller.php");
?>
