

<html>
<head>
</head>
<body>

<a href="Create_customer.php">Create customer</a>
<a href="Modify_customer.php">Modify customer</a>
<a href="List_customer.php">List customer</a>
<a href="Delete_customer.php">Delete customer</a>
<a href="#">Help</a>
<a href="#">About</a>
</body>
</html>
