<?php
require 'vendor/autoload.php'; // incluir lo bueno de Composer
?>
<?php

try
{
$cliente = new MongoDB\Client("mongodb+srv://adminDBproject:a1b2c3d@cluster0.vpt14.mongodb.net/test");
$coleccion = $cliente->customerdb->customers;

$cursor = $coleccion->find();
?>
<html>
<form action="Connection.php" method="post">
    
        <?php 
        echo "<table border='1'>";
          foreach ($cursor as $documento) {
      echo "<tr><td><a href='Modify_customer.php?id=".$_GET['_id'].";><input type='button' name='btn_modify' value='Modify'/></td><td>".$documento["name"] . "</td><td>". $documento["address"] . "</td><td> ". $documento["age"] . " </td><td>". $documento["password"] . "</td></tr>";
   }
   echo " </table>";
   }
   
catch(exception $ex)
{
    echo $ex;
}
?>
</form>
    <form action="#" method="post">
        <input type="text" name="txt_name" value=<?php $_POST['txt_name']?> />
    </form>
</html>