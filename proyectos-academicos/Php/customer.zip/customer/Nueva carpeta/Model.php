<?php
require_once 'Connection.php';
Class model
{
    private $con;
    private $collection;
    public function __construct()
    {
        $this->con=connection(); 
        $this->collection=set_collection();
    }
  
    public function get_customers()
    {
        $list_customers = $collection->find();
        return $list_customers;
    }
    public function set_customer()
    {
        $customer_information = array( 'name' => $_POST['txt_name'], 'address' => $_POST['txt_address'],'age' => $_POST['txt_age'], 'password' => $_POST['txt_password'] );
        $result = $collection->insertOne($customer_information);
        header('Location: http://localhost/customer');
    }
    public function modify_costumer()
    {
        
    }
    
    public function delete_costumer()
    {
        
    }
    
}

?>